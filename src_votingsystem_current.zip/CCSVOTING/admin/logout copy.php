<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '../../../../../../../../../../includes/config.php';
// Regular user logout

session_unset();
session_destroy();
header("Location: " . BASE_URL . "admin/login.php");
exit;