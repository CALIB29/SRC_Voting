<?php


require_once __DIR__ . '/includes/db_connect.php';
require_once __DIR__ . '/includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$department_id = $_SESSION['department_id'];

// 1. Get active election
$active_election = $pdo->query("SELECT id, title FROM vot_elections WHERE is_active = 1")->fetch(PDO::FETCH_ASSOC);

// 2. Check if already voted
$stmt_check = $pdo->prepare("SELECT has_voted FROM students WHERE student_id = ?");
$stmt_check->execute([$user_id]);
$voter = $stmt_check->fetch();

if ($voter && $voter['has_voted']) {
    header("Location: dashboard.php");
    exit;
}

// 3. Check schedule
$schedule_stmt = $pdo->query("SELECT start_datetime, end_datetime FROM vot_voting_schedule LIMIT 1");
$schedule = $schedule_stmt->fetch(PDO::FETCH_ASSOC);
$voting_allowed = false;
$status_message = "";

if ($schedule) {
    try {
        $now = new DateTime("now", new DateTimeZone('Asia/Manila'));
        $start = new DateTime($schedule['start_datetime'], new DateTimeZone('Asia/Manila'));
        $end = new DateTime($schedule['end_datetime'], new DateTimeZone('Asia/Manila'));

        if ($now >= $start && $now <= $end) {
            $voting_allowed = true;
        } elseif ($now < $start) {
            $status_message = "Voting starts on " . $start->format('M j, Y g:i A');
        } else {
            $status_message = "Voting ended on " . $end->format('M j, Y g:i A');
        }
    } catch (Exception $e) {
        $status_message = "Schedule error.";
    }
} else {
    $status_message = "No schedule set.";
}

if (!$active_election) {
    $voting_allowed = false;
    $status_message = "No active election.";
}

// 4. Get candidates group by position
$candidates_by_position = [];
if ($voting_allowed) {
    $stmt = $pdo->prepare("SELECT *, CONCAT(first_name, ' ', last_name) as full_name FROM vot_candidates WHERE election_id = ? AND department_id = ? ORDER BY position, last_name");
    $stmt->execute([$active_election['id'], $department_id]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $row) {
        $candidates_by_position[$row['position']][] = $row;
    }
}

// 5. Handle submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_vote']) && $voting_allowed) {
    $pdo->beginTransaction();
    try {
        foreach ($_POST as $key => $val) {
            if ($key === 'submit_vote')
                continue;

            $pos = str_replace('pos_', '', $key);
            $candidate_id = $val;

            $stmt = $pdo->prepare("INSERT INTO vot_votes (user_id, candidate_id, position, election_id) VALUES (?, ?, ?, ?)");
            $stmt->execute([$user_id, $candidate_id, $pos, $active_election['id']]);

            $stmt = $pdo->prepare("UPDATE vot_candidates SET votes = votes + 1 WHERE id = ?");
            $stmt->execute([$candidate_id]);
        }

        $stmt = $pdo->prepare("UPDATE students SET has_voted = 1 WHERE student_id = ?");
        $stmt->execute([$user_id]);

        $pdo->commit();
        $_SESSION['vote_success'] = true;
        header("Location: dashboard.php");
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Failed to submit vote: " . $e->getMessage();
    }
}

$page_title = "Cast Your Vote";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <?php renderAppHeader($page_title); ?>
    <style>
        .wizard-step {
            display: none;
        }

        .wizard-step.active {
            display: block;
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(20px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .candidate-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .candidate-card-vote {
            background: white;
            border-radius: 15px;
            padding: 15px;
            text-align: center;
            border: 2px solid #eee;
            cursor: pointer;
            transition: all 0.2s;
            position: relative;
        }

        .candidate-card-vote:hover {
            border-color: var(--primary);
            transform: translateY(-3px);
        }

        .candidate-card-vote.selected {
            border-color: var(--primary);
            background: var(--primary-light);
        }

        .candidate-card-vote.selected::after {
            content: '✓';
            position: absolute;
            top: 10px;
            right: 10px;
            background: var(--primary);
            color: white;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: bold;
        }

        .c-img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px;
            border: 3px solid #f0f0f0;
        }

        .c-name {
            font-weight: 700;
            font-size: 0.9rem;
            margin-bottom: 5px;
            color: #333;
        }

        .c-party {
            font-size: 0.75rem;
            color: #666;
            background: #f5f5f5;
            padding: 2px 8px;
            border-radius: 10px;
        }

        .wizard-footer {
            position: fixed;
            bottom: 70px;
            left: 0;
            right: 0;
            padding: 15px 20px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid #eee;
            z-index: 100;
        }

        .progress-dots {
            display: flex;
            gap: 6px;
        }

        .dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #ddd;
        }

        .dot.active {
            background: var(--primary);
            transform: scale(1.3);
        }

        .review-item {
            background: white;
            padding: 12px 15px;
            border-radius: 12px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        @media (min-width: 769px) {
            .wizard-footer {
                left: 280px;
                bottom: 0;
            }

            .candidate-grid {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            }
        }
    </style>
</head>

<body>
    <?php renderMobileTopBar($page_title); ?>
    <div class="app-container">
        <?php renderAppSidebar('student'); ?>
        <main class="main-content">

            <?php if (!$voting_allowed): ?>
                <div class="card status-card animate-up" style="text-align: center; padding: 40px 20px;">
                    <i class="fas fa-clock" style="font-size: 3rem; color: var(--warning); margin-bottom: 20px;"></i>
                    <h2 style="margin-bottom: 10px;">Voting Not Available</h2>
                    <p style="color: #666;"><?php echo $status_message; ?></p>
                    <a href="dashboard.php" class="btn"
                        style="margin-top:20px; display:inline-block; padding: 10px 30px;">Back to Dashboard</a>
                </div>
            <?php else: ?>

                <form id="voteForm" method="POST">
                    <?php
                    $positions = array_keys($candidates_by_position);
                    foreach ($positions as $index => $pos):
                        ?>
                        <div class="wizard-step <?php echo $index === 0 ? 'active' : ''; ?>" id="step-<?php echo $index; ?>">
                            <div style="margin-bottom: 20px;">
                                <span class="badge"
                                    style="background: var(--primary-light); color: var(--primary); padding: 5px 12px; border-radius: 20px; font-weight: 700;"><?php echo $pos; ?></span>
                                <h1 style="font-size: 1.5rem; font-weight: 800; margin-top: 10px;">Select your Candidate</h1>
                                <p style="color: #666; font-size: 0.9rem;">Choose one candidate for this position.</p>
                            </div>

                            <div class="candidate-grid">
                                <?php foreach ($candidates_by_position[$pos] as $c): ?>
                                    <div class="candidate-card-vote"
                                        onclick="selectCandidate('<?php echo $index; ?>', '<?php echo $pos; ?>', '<?php echo $c['id']; ?>', '<?php echo htmlspecialchars($c['full_name']); ?>', this)">
                                        <img src="<?php echo !empty($c['photo_path']) ? '../' . $c['photo_path'] : '../assets/img/default-avatar.png'; ?>"
                                            class="c-img" onerror="this.src='../assets/img/default-avatar.png'">
                                        <div class="c-name"><?php echo htmlspecialchars($c['full_name']); ?></div>
                                        <div class="c-party"><?php echo htmlspecialchars($c['party']); ?></div>
                                        <input type="radio" name="pos_<?php echo $pos; ?>" value="<?php echo $c['id']; ?>"
                                            style="display:none;" id="opt-<?php echo $c['id']; ?>">
                                    </div>
                                <?php endforeach; ?>

                                <div class="candidate-card-vote"
                                    onclick="selectCandidate('<?php echo $index; ?>', '<?php echo $pos; ?>', 'abstain', 'Abstain', this)">
                                    <div class="c-img"
                                        style="display:flex; align-items:center; justify-content:center; background:#f5f5f5;"><i
                                            class="fas fa-ban" style="font-size: 2rem; color: #ccc;"></i></div>
                                    <div class="c-name">Abstain</div>
                                    <div class="c-party">No Selection</div>
                                    <input type="radio" name="pos_<?php echo $pos; ?>" value="abstain" style="display:none;"
                                        id="opt-abstain-<?php echo $index; ?>">
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <!-- Review Step -->
                    <div class="wizard-step" id="step-<?php echo count($positions); ?>">
                        <div style="margin-bottom: 20px;">
                            <h1 style="font-size: 1.5rem; font-weight: 800;">Review Your Ballot</h1>
                            <p style="color: #666; font-size: 0.9rem;">Please double check your selection before submitting.
                            </p>
                        </div>

                        <div id="reviewList">
                            <!-- Populated by JS -->
                        </div>

                        <button type="submit" name="submit_vote" class="btn"
                            style="width: 100%; margin-top: 20px; padding: 15px; font-weight: 800; font-size: 1.1rem; border-radius: 12px; box-shadow: 0 8px 20px var(--primary-glow);">
                            <i class="fas fa-paper-plane" style="margin-right: 10px;"></i>
                            Submit Official Ballot
                        </button>
                    </div>

                    <div class="wizard-footer">
                        <button type="button" class="btn-ghost" id="prevBtn" onclick="moveStep(-1)"
                            style="display:none;">Back</button>
                        <div class="progress-dots">
                            <?php for ($i = 0; $i <= count($positions); $i++): ?>
                                <div class="dot <?php echo $i === 0 ? 'active' : ''; ?>" id="dot-<?php echo $i; ?>"></div>
                            <?php endfor; ?>
                        </div>
                        <button type="button" class="btn" id="nextBtn" onclick="moveStep(1)"
                            style="padding: 8px 25px; border-radius: 10px; font-weight: 700;">Next</button>
                    </div>
                </form>

            <?php endif; ?>
        </main>
    </div>
    <?php renderMobileBottomNav('student'); ?>

    <script>
        let currentStep = 0;
        const totalSteps = <?php echo count($positions); ?>;
        const selectedVotes = {};

        function selectCandidate(stepIdx, position, candidateId, name, element) {
            // Update UI
            const step = document.getElementById('step-' + stepIdx);
            step.querySelectorAll('.candidate-card-vote').forEach(card => card.classList.remove('selected'));
            element.classList.add('selected');

            // Select Radio
            const input = element.querySelector('input');
            input.checked = true;

            // Store for review
            selectedVotes[position] = name;

            // Auto next after selection on mobile? 
            // Better to let them click Next.
        }

        function moveStep(delta) {
            if (delta === 1) {
                // Check if selection made
                const currentStepEl = document.getElementById('step-' + currentStep);
                const selection = currentStepEl.querySelector('input:checked');

                if (!selection && currentStep < totalSteps) {
                    alert('Please select a candidate or Abstain to continue.');
                    return;
                }
            }

            document.getElementById('step-' + currentStep).classList.remove('active');
            document.getElementById('dot-' + currentStep).classList.remove('active');

            currentStep += delta;

            document.getElementById('step-' + currentStep).classList.add('active');
            document.getElementById('dot-' + currentStep).classList.add('active');

            // Update footer buttons
            document.getElementById('prevBtn').style.display = currentStep > 0 ? 'block' : 'none';
            document.getElementById('nextBtn').style.display = currentStep < totalSteps ? 'block' : 'none';

            // If entering review step, populate list
            if (currentStep === totalSteps) {
                populateReview();
            }
        }

        function populateReview() {
            const container = document.getElementById('reviewList');
            container.innerHTML = '';
            for (const [pos, name] of Object.entries(selectedVotes)) {
                const item = document.createElement('div');
                item.className = 'review-item';
                item.innerHTML = `
                    <div>
                        <div style="font-size: 0.7rem; color: #999; text-transform: uppercase; font-weight: 800;">${pos}</div>
                        <div style="font-weight: 700; color: #333;">${name}</div>
                    </div>
                    <i class="fas fa-check-circle" style="color: var(--success);"></i>
                `;
                container.appendChild(item);
            }
        }
    </script>
</body>

</html>