<?php

require_once __DIR__ . '/includes/db_connect.php';
require_once __DIR__ . '/includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

// Fetch user details from DB
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT s.*, c.course_name, d.department_name FROM students s LEFT JOIN courses c ON s.course_id = c.course_id LEFT JOIN departments d ON s.department_id = d.department_id WHERE s.student_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// If user not found in DB, log out
if (!$user) {
    session_destroy();
    header("Location: index.php");
    exit;
}

// Set session variables if not already set
if (!isset($_SESSION['first_name'])) {
    $_SESSION['first_name'] = $user['first_name'];
}

// Check if user has already voted
$has_voted = $user['has_voted'];

// Check for the latest concluded election to show celebration
$stmt_concluded = $pdo->query("SELECT id, title, end_datetime FROM vot_elections WHERE is_active = 0 AND end_datetime IS NOT NULL ORDER BY end_datetime DESC LIMIT 1");
$latest_concluded = $stmt_concluded->fetch();
$show_celebration = false;
if ($latest_concluded) {
    $now = new DateTime();
    $end_date = new DateTime($latest_concluded['end_datetime']);
    $diff = $now->diff($end_date);
    // Show celebration if it ended within the last 48 hours
    if ($diff->days < 2) {
        $show_celebration = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
    <?php renderAppHeader('Dashboard | SRC Voting'); ?>
</head>
<body>
<?php renderMobileTopBar('Dashboard'); ?>
<div class="app-container">
    <?php renderAppSidebar('student'); ?>
    <main class="main-content animate-up">
        <div class="welcome-header">
            <h2><i class="fas fa-user-graduate"></i> Welcome, <?php echo htmlspecialchars($_SESSION['first_name']); ?></h2>
            <div class="time-date">
                <i class="far fa-calendar-alt"></i> <span id="current-date"></span>
                <i class="far fa-clock" style="margin-left: 15px;"></i> <span id="current-time"></span>
            </div>
        </div>

        <?php if ($show_celebration): ?>
            <div class="celebration-banner" style="background: linear-gradient(135deg, var(--primary), var(--secondary)); color: white; padding: 1.5rem; border-radius: var(--border-radius); margin-bottom: 30px; display: flex; align-items: center; gap: 1.5rem; box-shadow: var(--box-shadow-lg); animation: slideIn 0.5s ease-out; position: relative; overflow: hidden;">
                <div style="font-size: 2.5rem;">🏆</div>
                <div style="flex: 1;">
                    <h3 style="margin: 0; font-size: 1.4rem; font-weight: 700; color: white;">Election Results are Out!</h3>
                    <p style="margin: 5px 0 0 0; opacity: 0.9;">The election "<?php echo htmlspecialchars($latest_concluded['title']); ?>" has ended. Check the results now!</p>
                    <a href="resultview.php" style="display: inline-block; margin-top: 10px; color: white; background: rgba(255,255,255,0.2); padding: 5px 15px; border-radius: 20px; text-decoration: none; font-weight: 600; font-size: 0.85rem; transition: background 0.3s;">View Full Results →</a>
                </div>
                <div style="font-size: 2.5rem;">✨</div>
            </div>
            <script>
                window.addEventListener('load', () => {
                    const duration = 4 * 1000;
                    const end = Date.now() + duration;
                    (function frame() {
                        confetti({ particleCount: 3, angle: 60, spread: 55, origin: { x: 0 }, colors: ['#4361ee', '#3f37c9', '#4cc9f0'] });
                        confetti({ particleCount: 3, angle: 120, spread: 55, origin: { x: 1 }, colors: ['#4361ee', '#3f37c9', '#4cc9f0'] });
                        if (Date.now() < end) { requestAnimationFrame(frame); }
                    }());
                });
            </script>
        <?php endif; ?>

        <?php if ($has_voted): ?>
            <div class="alert success" style="background: var(--primary-light); border-left: 4px solid var(--primary); padding: 20px; border-radius: 12px; margin-bottom: 25px; display: flex; align-items: center; gap: 15px;">
                <i class="fas fa-check-circle" style="color: var(--primary); font-size: 1.5rem;"></i>
                <div class="alert-content">
                    <p style="margin: 0; font-weight: 600;">Thank you for voting! Your vote has been recorded.</p>
                    <a href="resultview.php" style="color: var(--primary); text-decoration: none; font-size: 0.9rem; font-weight: 700;">View results →</a>
                </div>
            </div>
        <?php else: ?>
            <div class="alert info" style="background: var(--warning-light); border-left: 4px solid var(--warning); padding: 20px; border-radius: 12px; margin-bottom: 25px; display: flex; align-items: center; gap: 15px;">
                <i class="fas fa-vote-yea" style="color: var(--warning); font-size: 1.5rem;"></i>
                <div class="alert-content">
                    <p style="margin: 0; font-weight: 600;">You haven't voted yet. Exercise your right to vote!</p>
                    <a href="vote.php" style="color: var(--warning); text-decoration: none; font-size: 0.9rem; font-weight: 700;">Go to voting page →</a>
                </div>
            </div>
        <?php endif; ?>

        <div class="user-details" style="background: white; padding: 25px; border-radius: var(--border-radius); box-shadow: var(--box-shadow);">
            <h3 style="margin-top: 0; margin-bottom: 20px; display: flex; align-items: center; gap: 10px;"><i class="fas fa-id-card" style="color: var(--primary);"></i> Student Information</h3>
            <div class="user-details-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                <div class="detail-item">
                    <div style="font-size: 0.8rem; color: #777; font-weight: 600; text-transform: uppercase;">Student ID</div>
                    <div style="font-weight: 700; color: #333;"><?php echo htmlspecialchars($user['student_id']); ?></div>
                </div>
                <div class="detail-item">
                    <div style="font-size: 0.8rem; color: #777; font-weight: 600; text-transform: uppercase;">Course</div>
                    <div style="font-weight: 700; color: #333;"><?php echo htmlspecialchars($user['course_name'] ?? 'N/A'); ?></div>
                </div>
                <div class="detail-item">
                    <div style="font-size: 0.8rem; color: #777; font-weight: 600; text-transform: uppercase;">Department</div>
                    <div style="font-weight: 700; color: #333;"><?php echo htmlspecialchars($user['department_name'] ?? 'N/A'); ?></div>
                </div>
                <div class="detail-item">
                    <div style="font-size: 0.8rem; color: #777; font-weight: 600; text-transform: uppercase;">Voting Status</div>
                    <div style="font-weight: 700; color: <?php echo $has_voted ? 'var(--primary)' : 'var(--warning)'; ?>;">
                        <?php echo $has_voted ? 'Voted' : 'Pending'; ?>
                    </div>
                </div>
            </div>
        </div>

        <script>
            function updateDateTime() {
                const now = new Date();
                const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                document.getElementById('current-date').textContent = now.toLocaleDateString('en-US', options);
                document.getElementById('current-time').textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
            }
            setInterval(updateDateTime, 1000);
            updateDateTime();
        </script>
    </main>
</div>
<?php renderMobileBottomNav('student'); ?>
</body>
</html>