<?php

/**
 * Proxy for the root functions file
 * Created to support modern layout features across all departments
 */
require_once __DIR__ . '/../../includes/functions.php';
?>