<?php

require_once __DIR__ . '/../../includes/db_connect.php';
require_once __DIR__ . '/../../includes/functions.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../../admin/login.php");
    exit;
}

$dept_id = $_SESSION['department_id'];

// Stats for current department
$total_voters = $pdo->prepare("SELECT COUNT(*) FROM students WHERE department_id = ?");
$total_voters->execute([$dept_id]);
$total_voters = $total_voters->fetchColumn();

$voted_count = $pdo->prepare("SELECT COUNT(*) FROM students WHERE department_id = ? AND has_voted = 1");
$voted_count->execute([$dept_id]);
$voted_count = $voted_count->fetchColumn();

$candidate_count = $pdo->prepare("SELECT COUNT(*) FROM vot_candidates WHERE department_id = ?");
$candidate_count->execute([$dept_id]);
$candidate_count = $candidate_count->fetchColumn();

// Fetch latest election winners
require_once '../../includes/get_winners.php';
$winnersData = getLatestElectionWinners($pdo);

$page_title = "Admin Dashboard";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <?php renderAppHeader($page_title); ?>
    <style>
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--box-shadow);
            text-align: center;
            border: 1px solid #eee;
        }

        .stat-value {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--primary);
            display: block;
        }

        .stat-label {
            font-size: 0.8rem;
            color: #777;
            font-weight: 600;
            text-transform: uppercase;
        }

        .winner-card {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: #f8faff;
            border-radius: 12px;
            margin-bottom: 15px;
            border-left: 4px solid var(--primary);
        }

        .winner-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }
    </style>
</head>

<body>
    <?php renderMobileTopBar($page_title); ?>
    <div class="app-container">
        <?php renderAppSidebar('admin'); ?>
        <main class="main-content animate-up">
            <div class="welcome-header">
                <h2><i class="fas fa-shield-alt"></i> Admin Panel</h2>
                <p style="color: #666; margin: 0;">Managing <?php echo $_SESSION['department_name']; ?></p>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-value"><?php echo $total_voters; ?></span>
                    <span class="stat-label">Registered Voters</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value"><?php echo $voted_count; ?></span>
                    <span class="stat-label">Votes Cast</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value"><?php echo $candidate_count; ?></span>
                    <span class="stat-label">Candidates</span>
                </div>
            </div>

            <div class="card"
                style="background: white; padding: 25px; border-radius: var(--border-radius); box-shadow: var(--box-shadow); margin-bottom: 30px;">
                <h3 style="margin-top: 0; margin-bottom: 20px;"><i class="fas fa-trophy" style="color: #FFD700;"></i>
                    Election Winners</h3>
                <?php if ($winnersData && !empty($winnersData['winners'])): ?>
                    <?php foreach ($winnersData['winners'] as $winner): ?>
                        <div class="winner-card">
                            <img src="../../<?php echo !empty($winner['photo_path']) ? $winner['photo_path'] : 'assets/img/default-avatar.png'; ?>"
                                class="winner-avatar">
                            <div>
                                <div style="font-weight: 700; color: #333;">
                                    <?php echo htmlspecialchars($winner['first_name'] . ' ' . $winner['last_name']); ?></div>
                                <div style="font-size: 0.8rem; color: var(--primary); font-weight: 600;">
                                    <?php echo strtoupper($winner['position']); ?></div>
                            </div>
                            <div style="margin-left: auto; text-align: right;">
                                <div style="font-weight: 800; color: var(--primary);"><?php echo $winner['votes']; ?></div>
                                <div style="font-size: 0.7rem; color: #999;">Votes</div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="color: #999; text-align: center; padding: 20px;">No election results available yet.</p>
                <?php endif; ?>
            </div>

            <div class="quick-actions" style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <a href="manage_users.php" class="btn"
                    style="padding: 15px; text-decoration: none; border-radius: 12px; text-align: center; background: var(--primary-light); color: var(--primary); box-shadow: none;">
                    <i class="fas fa-users"></i><br>Voters
                </a>
                <a href="manage_candidates.php" class="btn"
                    style="padding: 15px; text-decoration: none; border-radius: 12px; text-align: center; background: var(--primary-light); color: var(--primary); box-shadow: none;">
                    <i class="fas fa-user-tie"></i><br>Candidates
                </a>
            </div>
        </main>
    </div>
    <?php renderMobileBottomNav('admin'); ?>
</body>

</html>