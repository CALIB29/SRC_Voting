<?php

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit;
}

// Get all students
try {
    $users = $pdo->query("SELECT student_id, first_name, middle_name, last_name, email, is_approved, has_voted FROM students ORDER BY is_approved, first_name, middle_name, last_name")->fetchAll();
} catch (PDOException $e) {
    $error = "Failed to load students: " . $e->getMessage();
    $users = array();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    
    
    

    <!-- EmailJS SDK -->
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js"></script>
    <script type="text/javascript">
        (function () {
            emailjs.init("OIX5KA4zIfVfAWlsV"); // Your public key
        })();
    </script>

    
    
    <link rel="stylesheet" href="../../assets/css/modern_admin.css">

    <style>
        .gmail-cell {
            max-width: 250px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* Modern Modal Styles Overrides */
        .confirmation-modal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.8);
            backdrop-filter: blur(8px);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .confirmation-modal-content {
            background: var(--bg-sidebar);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            width: 90%;
            max-width: 500px;
            overflow: hidden;
            box-shadow: var(--shadow);
            animation: modalFadeIn 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        @keyframes modalFadeIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }

            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .modal-header {
            padding: 2rem;
            display: flex;
            align-items: center;
            gap: 1.5rem;
            border-bottom: 1px solid var(--border);
        }

        .modal-body {
            padding: 2rem;
        }

        .modal-footer {
            padding: 1.5rem 2rem;
            background: rgba(255, 255, 255, 0.02);
            border-top: 1px solid var(--border);
            display: flex;
            justify-content: flex-end;
            gap: 1rem;
        }

        .loading-spinner {
            display: none;
            width: 20px;
            height: 20px;
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-top: 2px solid var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        .email-status {
            padding: 1rem;
            border-radius: var(--radius-md);
            margin-top: 1.5rem;
            display: none;
            font-size: 0.875rem;
        }

        .email-status.success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .email-status.error {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }
    </style>

    <link rel="stylesheet" href="../../assets/css/mobile_base.css">
<?php renderAppHeader('CBSVOTING Admin manage_users.php'); ?>
</head>




<body>
<?php renderMobileTopBar('CBSVOTING Admin manage_users.php'); ?>
<div class="app-container">
    <?php renderAppSidebar('admin'); ?>
    <main class="main-content animate-up">
        


    
    
        


    
    
        
            

            <div id="dynamicAlert" style="display: none; margin-bottom: 2rem;" class="modern-card"></div>

            <div class="search-container">
                <i class="fas fa-search"></i>
                <input type="text" id="voterSearch" class="modern-input" placeholder="Search by name, ID or email..."
                    onkeyup="filterTable()">
            </div>

            <div class="modern-table-container">
                <table class="modern-table" id="usersTable">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Voted</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="usersTableBody">
                        <?php foreach ($users as $user): ?>
                            <tr id="user-row-<?php echo htmlspecialchars($user['student_id']); ?>">
                                <td style="font-family: monospace; font-weight: 600;">
                                    <?php echo htmlspecialchars($user['student_id']); ?>
                                </td>
                                <td>
                                    <div style="font-weight: 600; color: var(--text-main);">
                                        <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>
                                    </div>
                                    <div style="font-size: 0.75rem; color: var(--text-muted);">
                                        <?php echo htmlspecialchars($user['middle_name'] ?? ''); ?>
                                    </div>
                                </td>
                                <td class="gmail-cell">
                                    <?php if (!empty($user['email'])): ?>
                                        <span title="<?php echo htmlspecialchars($user['email']); ?>">
                                            <?php echo htmlspecialchars($user['email']); ?>
                                        </span>
                                    <?php else: ?>
                                        <span style="color: var(--text-muted); font-style: italic;">N/A</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span
                                        class="status-badge <?php echo $user['is_approved'] ? 'badge-success' : 'badge-warning'; ?>">
                                        <?php echo $user['is_approved'] ? '<i class="fas fa-check"></i> Approved' : '<i class="fas fa-clock"></i> Pending'; ?>
                                    </span>
                                </td>
                                <td>
                                    <span
                                        class="status-badge <?php echo $user['has_voted'] ? 'badge-primary' : 'badge-danger'; ?>">
                                        <?php echo $user['has_voted'] ? 'Yes' : 'No'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 0.5rem;">
                                        <?php if (!$user['is_approved']): ?>
                                            <button
                                                onclick="showConfirmation('approve', '<?php echo htmlspecialchars($user['student_id']); ?>', '<?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>', '<?php echo htmlspecialchars($user['email'] ?? ''); ?>')"
                                                class="modern-btn modern-btn-primary" style="padding: 0.5rem 1rem;">
                                                <i class="fas fa-check"></i>
                                            </button>
                                            <button
                                                onclick="showConfirmation('reject', '<?php echo htmlspecialchars($user['student_id']); ?>', '<?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>', '<?php echo htmlspecialchars($user['email'] ?? ''); ?>')"
                                                class="modern-btn modern-btn-danger" style="padding: 0.5rem 1rem;">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        <?php else: ?>
                                            <span style="color: var(--success); font-weight: 600; font-size: 0.8rem;">
                                                <i class="fas fa-verified"></i> Active
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        
    


    


    </main>
</div>
<?php renderMobileBottomNav('admin'); ?>
</body></html>