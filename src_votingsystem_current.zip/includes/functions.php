<?php
/**
 * Helper functions for the voting system
 */

/**
 * Sanitize input data
 * @param string $data The input data to sanitize
 * @return string The sanitized data
 */
function sanitizeInput($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Redirect to a specified URL
 * @param string $url The URL to redirect to
 * @param int $statusCode HTTP status code (default: 303)
 */
function redirect($url, $statusCode = 303)
{
    header('Location: ' . $url, true, $statusCode);
    exit();
}

/**
 * Check if user is logged in
 * @return bool True if user is logged in, false otherwise
 */
function isUserLoggedIn()
{
    return isset($_SESSION['user_id']);
}

/**
 * Check if admin is logged in
 * @return bool True if admin is logged in, false otherwise
 */
function isAdminLoggedIn()
{
    return isset($_SESSION['admin_id']);
}

/**
 * Generate a random string (for potential password resets or tokens)
 * @param int $length Length of the random string
 * @return string The generated random string
 */
function generateRandomString($length = 10)
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

/**
 * Format date for display
 * @param string $date The date string to format
 * @param string $format The format to use (default: 'F j, Y, g:i a')
 * @return string The formatted date
 */
function formatDate($date, $format = 'F j, Y, g:i a')
{
    $dateTime = new DateTime($date);
    return $dateTime->format($format);
}

/**
 * Get the current URL
 * @return string The current URL
 */
function getCurrentUrl()
{
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
    return $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}

/**
 * Validate image upload
 * @param array $file The $_FILES array element
 * @param int $maxSize Maximum file size in bytes (default: 2MB)
 * @return array Array with 'valid' boolean and 'message' string
 */
function validateImageUpload($file, $maxSize = 2097152)
{
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['valid' => false, 'message' => 'File upload error'];
    }

    if ($file['size'] > $maxSize) {
        return ['valid' => false, 'message' => 'File is too large. Maximum size is ' . ($maxSize / 1024 / 1024) . 'MB'];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, $allowedTypes)) {
        return ['valid' => false, 'message' => 'Only JPG, PNG, and GIF files are allowed'];
    }

    return ['valid' => true, 'message' => 'File is valid'];
}

/**
 * Get user by ID
 * @param PDO $pdo Database connection
 * @param int $id User ID
 * @return array|false User data or false if not found
 */
function getUserById($pdo, $id)
{
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/**
 * Get candidate by ID
 * @param PDO $pdo Database connection
 * @param int $id Candidate ID
 * @return array|false Candidate data or false if not found
 */
function getCandidateById($pdo, $id)
{
    $stmt = $pdo->prepare("SELECT * FROM vot_candidates WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/**
 * Check if student ID already exists
 * @param PDO $pdo Database connection
 * @param string $student_id Student ID to check
 * @return bool True if exists, false otherwise
 */
function studentIdExists($pdo, $student_id)
{
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE student_id = ?");
    $stmt->execute([$student_id]);
    return $stmt->fetchColumn() > 0;
}

/**
 * Get all positions from vot_candidates table
 * @param PDO $pdo Database connection
 * @return array Array of distinct positions
 */
function getAllPositions($pdo)
{
    $stmt = $pdo->query("SELECT DISTINCT position FROM vot_candidates ORDER BY position");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

/**
 * Centered Admin Authentication Logic
 */
function authenticateAdmin($pdo, $email, $password)
{
    try {
        $stmt = $pdo->prepare("
            SELECT e.*, d.department_name, r.role_name
            FROM employees e
            LEFT JOIN departments d ON e.department_id = d.department_id
            LEFT JOIN roles r ON e.role_id = r.role_id
            WHERE e.email = ?
        ");
        $stmt->execute([$email]);
        $employee = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($employee) {
            if (password_verify($password, $employee['password']) || $password === $employee['password']) {
                return [
                    'success' => true,
                    'data' => [
                        'admin_id' => $employee['employee_id'],
                        'admin_name' => $employee['firstname'] . " " . $employee['lastname'],
                        'admin_role' => $employee['role_name'],
                        'department_id' => $employee['department_id'],
                        'department_name' => $employee['department_name']
                    ]
                ];
            }
        }
        return ['success' => false, 'message' => "Invalid email or password."];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => "Login failed: " . $e->getMessage()];
    }
}

/**
 * Get vote results by position
 * @param PDO $pdo Database connection
 * @param string $position The position to get results for
 * @return array Array of candidates with their vote counts
 */
/**
 * Get the redirect path for a department
 */
function getDepartmentRedirect($dept_id, $isAdmin = false)
{
    $map = [
        2 => [
            'folder' => 'CCSVOTING',
            'admin' => 'CCSVOTING/admin/dashboard.php',
            'student' => 'CCSVOTING/dashboard.php'
        ],
        3 => [
            'folder' => 'COEVOTING',
            'admin' => 'COEVOTING/admin/dashboard.php',
            'student' => 'COEVOTING/dashboard.php'
        ],
        4 => [
            'folder' => 'CBSVOTING',
            'admin' => 'CBSVOTING/admin/dashboard.php',
            'student' => 'CBSVOTING/dashboard.php'
        ],
        6 => [
            'folder' => 'ELEMENTARY',
            'admin' => 'ELEMENTARY/admin/dashboard.php',
            'student' => 'ELEMENTARY/dashboard.php'
        ],
        5 => [
            'folder' => 'INTEGRATED',
            'admin' => 'INTEGRATED/admin/dashboard.php',
            'student' => 'INTEGRATED/dashboard.php'
        ]
    ];

    if (!isset($map[$dept_id]))
        return null;

    return $isAdmin ? $map[$dept_id]['admin'] : $map[$dept_id]['student'];
}

function getVoteResultsByPosition($pdo, $position)
{
    $stmt = $pdo->prepare("SELECT * FROM vot_candidates WHERE position = ? ORDER BY votes DESC");
    $stmt->execute([$position]);
    return $stmt->fetchAll();
}

/**
 * Render standard app header
 */
function renderAppHeader($title)
{
    ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($title); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/app_core.css">
    <?php
}

/**
 * Render mobile top bar
 */
function renderMobileTopBar($title = '')
{
    ?>
    <div class="mobile-top-bar" style="display: none;">
        <div class="mobile-logo">
            <img src="<?php echo BASE_URL; ?>logo/srclogo.png" alt="Logo">
            <span><?php echo htmlspecialchars($title); ?></span>
        </div>
        <button class="mobile-menu-toggle" onclick="document.body.classList.toggle('sidebar-open')">
            <i class="fas fa-bars"></i>
        </button>
    </div>
    <?php
}

/**
 * Render application sidebar
 */
function renderAppSidebar($type = 'student')
{
    $current_page = basename($_SERVER['PHP_SELF']);
    ?>
    <aside class="sidebar">
        <div class="sidebar-header">
            <img src="<?php echo BASE_URL; ?>logo/srclogo.png" alt="Logo">
            <span>Santa Rita College</span>
        </div>
        <ul class="sidebar-menu">
            <?php if ($type === 'admin'): ?>
                <li class="<?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a>
                </li>
                <li
                    class="<?php echo in_array($current_page, ['manage_users.php', 'approve_students.php']) ? 'active' : ''; ?>">
                    <a href="manage_users.php"><i class="fas fa-users"></i> <span>Voter Management</span></a>
                </li>
                <li class="<?php echo $current_page == 'manage_candidates.php' ? 'active' : ''; ?>">
                    <a href="manage_candidates.php"><i class="fas fa-user-tie"></i> <span>Candidates</span></a>
                </li>
                <li class="<?php echo in_array($current_page, ['results.php', 'history.php']) ? 'active' : ''; ?>">
                    <a href="results.php"><i class="fas fa-poll-h"></i> <span>Elections & Results</span></a>
                </li>
                <li class="<?php echo $current_page == 'manage_history.php' ? 'active' : ''; ?>">
                    <a href="manage_history.php"><i class="fas fa-archive"></i> <span>History Archive</span></a>
                </li>
            <?php else: ?>
                <li class="<?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                    <a href="dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a>
                </li>
                <li class="<?php echo $current_page == 'vote.php' ? 'active' : ''; ?>">
                    <a href="vote.php"><i class="fas fa-vote-yea"></i> <span>Vote Now</span></a>
                </li>
                <li class="<?php echo $current_page == 'view.php' ? 'active' : ''; ?>">
                    <a href="view.php"><i class="fas fa-users"></i> <span>Candidates</span></a>
                </li>
                <li class="<?php echo $current_page == 'resultview.php' ? 'active' : ''; ?>">
                    <a href="resultview.php"><i class="fas fa-chart-bar"></i> <span>Results</span></a>
                </li>
            <?php endif; ?>
        </ul>
        <div class="sidebar-footer">
            <a href="logout.php" class="logout-link">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </div>
    </aside>
    <?php
}

/**
 * Render mobile bottom navigation
 */
function renderMobileBottomNav($type = 'student')
{
    $current_page = basename($_SERVER['PHP_SELF']);
    // Optional: Hide on desktop via CSS in app_core.css
    ?>
    <style>
        @media (max-width: 768px) {
            .mobile-bottom-nav {
                display: flex !important;
                position: fixed;
                bottom: 0;
                left: 0;
                right: 0;
                background: white;
                border-top: 1px solid var(--border);
                padding: 0.75rem 0;
                justify-content: space-around;
                z-index: 1000;
            }

            .mobile-bottom-nav a {
                color: var(--text-secondary) !important;
                text-decoration: none !important;
                font-size: 0.75rem !important;
                display: flex !important;
                flex-direction: column !important;
                align-items: center !important;
                gap: 0.25rem !important;
            }

            .mobile-bottom-nav a.active {
                color: var(--primary) !important;
            }

            .mobile-bottom-nav i {
                font-size: 1.25rem !important;
            }

            body {
                padding-bottom: 70px !important;
            }
        }

        @media (min-width: 769px) {
            .mobile-bottom-nav {
                display: none !important;
            }
        }
    </style>
    <nav class="mobile-bottom-nav" style="display: none;">
        <?php if ($type === 'admin'): ?>
            <a href="dashboard.php" class="<?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                <i class="fas fa-tachometer-alt"></i><span>Home</span>
            </a>
            <a href="manage_users.php" class="<?php echo $current_page == 'manage_users.php' ? 'active' : ''; ?>">
                <i class="fas fa-users"></i><span>Users</span>
            </a>
            <a href="results.php" class="<?php echo $current_page == 'results.php' ? 'active' : ''; ?>">
                <i class="fas fa-poll-h"></i><span>Polls</span>
            </a>
        <?php else: ?>
            <a href="dashboard.php" class="<?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                <i class="fas fa-home"></i><span>Home</span>
            </a>
            <a href="vote.php" class="<?php echo $current_page == 'vote.php' ? 'active' : ''; ?>">
                <i class="fas fa-vote-yea"></i><span>Vote</span>
            </a>
            <a href="resultview.php" class="<?php echo $current_page == 'resultview.php' ? 'active' : ''; ?>">
                <i class="fas fa-chart-bar"></i><span>Results</span>
            </a>
        <?php endif; ?>
    </nav>
    <?php
}
