<?php
// Standardized connection: Mandatory use of root includes/db_connect.php
require_once __DIR__ . '/../../includes/db_connect.php';
?>