RENAME TABLE `departments` TO `vot_departments`;
RENAME TABLE `employees` TO `vot_employees`;
