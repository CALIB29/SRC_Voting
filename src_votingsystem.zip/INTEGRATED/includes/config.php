<?php
// Basic configuration
define('BASE_URL', 'http://localhost/voting_system/');
define('MAX_LOGIN_ATTEMPTS', 3);
define('UPLOAD_DIR', '../uploads/');
?>